package com.example.rehberim;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.nio.charset.StandardCharsets;

public class sms extends AppCompatActivity {
    EditText no;
    EditText sms;
    Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms2);

        no=(EditText)findViewById(R.id.editTextPhone2);
        sms=(EditText)findViewById(R.id.editTextTextMultiLine);
        btn=(Button)findViewById(R.id.button);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mesaj=sms.getText().toString();
                String numara=no.getText().toString();
                android.telephony.SmsManager sms=android.telephony.SmsManager.getDefault();
                sms.sendTextMessage(numara,null,mesaj,null,null);
            }
        });


    }
}